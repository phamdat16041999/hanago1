<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div id="footer" style="margin-top: 10%">
	<div class="endpage">
		<table border="0" width="100%" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td align="left" valign="top">
						<p style="font-size:12px">
							<strong>Copyright © 2011: </strong><strong>Công ty cổ phần HANAGO quốc tế </strong>- Hotline : <strong>0968. 353.436</strong><br>
							<strong>Trụ sở chính: </strong>Số 5 Ngõ 10, Phố Võng Thị, Phường Bưởi, Q. Tây Hồ, TP.Hà Nội<br>
							<strong>Email: </strong>Hanago2526@gmail.com
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		</div>

</div>
</body>
</html>